package com.company.Adopter;

public interface SimpleCustomer {
    public void Buy();
}
