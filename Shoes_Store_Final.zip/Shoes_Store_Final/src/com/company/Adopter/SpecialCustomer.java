package com.company.Adopter;

public interface SpecialCustomer {
        public void discount10();
        public void freeDelivery();
        public void ContestChance();
}
