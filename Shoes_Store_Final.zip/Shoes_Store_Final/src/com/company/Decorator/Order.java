package com.company.Decorator;

public interface Order {
    public String getDescription();
    public double getPrice();
}
