package com.company.Factory;

public interface Factory {
    public Shoes createCleats();
    public Shoes createTrainers();
    public Shoes createSneakers();
}
