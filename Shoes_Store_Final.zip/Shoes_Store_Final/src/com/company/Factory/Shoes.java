package com.company.Factory;

public interface Shoes {
    public void type();
}
