package com.company.Factory;

public class  Sneakers extends FactoryShoes implements Shoes{

    public void type(){
       System.out.println("great shoes for running activities");
   }
}
