package com.company.Strategy;

public interface Payment {

    public void ChoosePayment();
    public void paymentDetails();
}
